from flask import Flask,render_template,request,redirect,url_for,session,flash
from werkzeug.security import generate_password_hash,check_password_hash
from werkzeug.utils import secure_filename
import sqlite3,os
from pathlib import Path
BASE=Path(__file__).parent; DB=BASE/'mrwear.db'; UP=BASE/'static/uploads'; UP.mkdir(parents=True,exist_ok=True)
app=Flask(__name__); app.secret_key=os.environ.get('MRWEAR_SECRET','change-this-before-publishing')
ADMIN='admin'; PASSWORD_HASH=generate_password_hash(os.environ.get('MRWEAR_PASSWORD','MRWear@2026'))
def conn():
 c=sqlite3.connect(DB); c.row_factory=sqlite3.Row; return c
def init():
 c=conn(); c.execute('CREATE TABLE IF NOT EXISTS articles(id INTEGER PRIMARY KEY AUTOINCREMENT,title TEXT,content TEXT,image TEXT)')
 if not c.execute('SELECT 1 FROM articles').fetchone(): c.execute('INSERT INTO articles(title,content,image) VALUES(?,?,?)',('Welcome to MR Wear','Premium jackets and fashion wear by MOHIB RUKHSAR (MR) WEAR.','uploads/mr-wear-cover.png'))
 c.commit(); c.close()
@app.context_processor
def info(): return dict(brand='MOHIB RUKHSAR (MR) WEAR',owner='Syed Mohib Ali Shah',email='smohib224@gmail.com',whatsapp='03182051773',website='www.mrwear.pk')
@app.route('/')
def home():
 c=conn(); a=c.execute('SELECT * FROM articles ORDER BY id DESC').fetchall(); c.close(); return render_template('home.html',articles=a)
@app.route('/login',methods=['GET','POST'])
def login():
 if request.method=='POST' and request.form.get('username')==ADMIN and check_password_hash(PASSWORD_HASH,request.form.get('password','')): session['admin']=1; return redirect('/admin')
 if request.method=='POST': flash('Invalid ID or password.')
 return render_template('login.html')
@app.route('/logout')
def logout(): session.clear(); return redirect('/')
def ok(): return session.get('admin')==1
@app.route('/admin')
def admin():
 if not ok(): return redirect('/login')
 c=conn(); a=c.execute('SELECT * FROM articles ORDER BY id DESC').fetchall(); c.close(); return render_template('admin.html',articles=a)
@app.route('/admin/new',methods=['GET','POST'])
def new():
 if not ok(): return redirect('/login')
 if request.method=='POST':
  f=request.files.get('image'); img=''
  if f and f.filename: n=secure_filename(f.filename); f.save(UP/n); img='uploads/'+n
  c=conn(); c.execute('INSERT INTO articles(title,content,image) VALUES(?,?,?)',(request.form['title'],request.form['content'],img)); c.commit(); c.close(); return redirect('/admin')
 return render_template('form.html',article=None)
@app.route('/admin/edit/<int:i>',methods=['GET','POST'])
def edit(i):
 if not ok(): return redirect('/login')
 c=conn(); a=c.execute('SELECT * FROM articles WHERE id=?',(i,)).fetchone()
 if request.method=='POST':
  img=a['image']; f=request.files.get('image')
  if f and f.filename: n=secure_filename(f.filename); f.save(UP/n); img='uploads/'+n
  c.execute('UPDATE articles SET title=?,content=?,image=? WHERE id=?',(request.form['title'],request.form['content'],img,i)); c.commit(); c.close(); return redirect('/admin')
 c.close(); return render_template('form.html',article=a)
@app.post('/admin/delete/<int:i>')
def delete(i):
 if not ok(): return redirect('/login')
 c=conn(); c.execute('DELETE FROM articles WHERE id=?',(i,)); c.commit(); c.close(); return redirect('/admin')
if __name__=='__main__': init(); app.run(host='127.0.0.1',port=5000)
