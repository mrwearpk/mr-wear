MR WEAR - WEBSITE + ADMIN CMS

Default local login:
ID: admin
Password: MRWear@2026

Windows:
1. Install Python 3.11+
2. Open Command Prompt in this folder
3. py -m pip install -r requirements.txt
4. py app.py
5. Open http://127.0.0.1:5000
6. Owner Login -> add/edit/delete articles and upload images.

For www.mrwear.pk, deploy this Flask app to a hosting/VPS and point the domain to it. Change the default password and secret before publishing.
